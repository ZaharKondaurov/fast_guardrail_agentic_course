"""Frozen ensemble solver: CatBoost (2 variants) + byte transformer probability blend.

Inference dependencies: Python stdlib, NumPy, SciPy, CatBoost, ONNX Runtime.
"""
import hashlib
import json
import math
import os
import sys
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import numpy as np
import onnxruntime as ort
from catboost import CatBoostClassifier
from scipy.sparse import csr_matrix

import cat_features
import numeric_features

BASE = Path(__file__).resolve().parent
SEQUENCE_LENGTH = 192
CLS_ID = 257
WORD_BUCKETS = 4096
HEAD_WORDS = 40
TAIL_WORDS = 24
_STATE = None


def _sigmoid(x):
    if x >= 0:
        return 1.0 / (1.0 + math.exp(-x))
    z = math.exp(x)
    return z / (1.0 + z)


def _load():
    vocab = cat_features.load_vocab(BASE / "vocab.txt")
    tuned_meta = json.loads((BASE / "cat_tuned_meta.json").read_text(encoding="utf-8"))
    feat_meta = json.loads((BASE / "cat_feat_meta.json").read_text(encoding="utf-8"))
    idf = np.load(BASE / "idf.npz")["idf"].astype(np.float64).tolist()
    tuned = CatBoostClassifier(); tuned.load_model(str(BASE / "cat_tuned.cbm"))
    feat = CatBoostClassifier(); feat.load_model(str(BASE / "cat_feat.cbm"))
    options = ort.SessionOptions(); options.intra_op_num_threads = 1
    session = ort.InferenceSession(str(BASE / "trans_model.onnx"), sess_options=options,
                                   providers=["CPUExecutionProvider"])
    return {"meta": json.loads((BASE / "meta.json").read_text(encoding="utf-8")),
            "vocab": vocab, "idf": idf, "tuned_meta": tuned_meta, "feat_meta": feat_meta,
            "tuned": tuned, "feat": feat, "session": session}


def state():
    global _STATE
    if _STATE is None:
        _STATE = _load()
    return _STATE


def _encode_bytes(text):
    tokens = np.zeros((1, SEQUENCE_LENGTH), dtype=np.int64)
    tokens[0, 0] = CLS_ID
    raw = text.encode("utf-8", "surrogatepass")[: SEQUENCE_LENGTH - 1]
    if raw:
        tokens[0, 1:1 + len(raw)] = np.frombuffer(raw, dtype=np.uint8).astype(np.int64) + 1
    return tokens


def _encode_words(text):
    width = HEAD_WORDS + TAIL_WORDS
    out = np.zeros((1, width), dtype=np.int64)
    words = text.lower().split()
    if len(words) > width:
        words = words[:HEAD_WORDS] + words[-TAIL_WORDS:]
    for slot, word in enumerate(words):
        digest = hashlib.blake2b(word.encode("utf-8", "surrogatepass"), digest_size=8).digest()
        out[0, slot] = int.from_bytes(digest, "little") % WORD_BUCKETS + 1
    return out


def score(text):
    st = state()
    max_n = int(st["tuned_meta"]["max_n"])
    indices, values = cat_features.vectorize(text, st["vocab"], st["idf"], max_n)
    base = csr_matrix(
        (np.asarray(values, dtype=np.float32), np.asarray(indices, dtype=np.int32),
         np.asarray([0, len(indices)], dtype=np.int64)),
        shape=(1, int(st["tuned_meta"]["n_features"])))
    p_tuned = float(st["tuned"].predict_proba(base, thread_count=1)[0, 1])
    feats = list(numeric_features.extract(text))
    feature_count = len(st["vocab"])
    indices2 = indices + [feature_count + i for i in range(len(feats))]
    values2 = values + feats
    full = csr_matrix(
        (np.asarray(values2, dtype=np.float32), np.asarray(indices2, dtype=np.int32),
         np.asarray([0, len(indices2)], dtype=np.int64)),
        shape=(1, int(st["feat_meta"]["n_features"])))
    p_feat = float(st["feat"].predict_proba(full, thread_count=1)[0, 1])
    raw, = st["session"].run(None, {"tokens": _encode_bytes(text),
                                    "words": _encode_words(text)})
    p_trans = _sigmoid(float(raw[0]))
    meta = st["meta"]
    return (float(meta["w_cat"]) * p_tuned + float(meta["w_catfeat"]) * p_feat
            + float(meta["w_trans"]) * p_trans)


def main():
    task = json.load(sys.stdin)
    probability = score(task.get("input", ""))
    print(json.dumps({"answer": str(int(probability > float(state()["meta"]["threshold"])))}))


if __name__ == "__main__":
    main()
