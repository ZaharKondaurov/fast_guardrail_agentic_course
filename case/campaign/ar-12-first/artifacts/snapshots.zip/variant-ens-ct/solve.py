"""Frozen ensemble solver: probability blend of linear TF-IDF, CatBoost and byte transformer.

Inference dependencies: Python stdlib, NumPy, SciPy, CatBoost, ONNX Runtime.
"""
import hashlib
import json
import math
import os
import sys
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import numpy as np
import onnxruntime as ort
from catboost import CatBoostClassifier
from scipy.sparse import csr_matrix

import cat_features
import linear_features

BASE = Path(__file__).resolve().parent
SEQUENCE_LENGTH = 192
CLS_ID = 257
WORD_BUCKETS = 4096
HEAD_WORDS = 40
TAIL_WORDS = 24
_STATE = None


def _sigmoid(x):
    if x >= 0:
        return 1.0 / (1.0 + math.exp(-x))
    z = math.exp(x)
    return z / (1.0 + z)


def _load_linear():
    vocab = {}
    with (BASE / "linear_vocab.txt").open(encoding="utf-8") as stream:
        for index, line in enumerate(stream):
            vocab[line.rstrip("\n")] = index
    data = np.load(BASE / "linear_model.npz")
    return (vocab, data["idf"].astype(np.float64).tolist(),
            data["coef"].astype(np.float64), float(data["intercept"]))


def _load_cat():
    vocab = cat_features.load_vocab(BASE / "cat_vocab.txt")
    meta = json.loads((BASE / "cat_meta.json").read_text(encoding="utf-8"))
    idf = np.load(BASE / "cat_idf.npz")["idf"].astype(np.float64).tolist()
    model = CatBoostClassifier()
    model.load_model(str(BASE / "cat_model.cbm"))
    return vocab, idf, model, meta


def _load_trans():
    options = ort.SessionOptions()
    options.intra_op_num_threads = 1
    session = ort.InferenceSession(str(BASE / "trans_model.onnx"), sess_options=options,
                                   providers=["CPUExecutionProvider"])
    return session


def _encode_bytes(text):
    tokens = np.zeros((1, SEQUENCE_LENGTH), dtype=np.int64)
    tokens[0, 0] = CLS_ID
    raw = text.encode("utf-8", "surrogatepass")[: SEQUENCE_LENGTH - 1]
    if raw:
        tokens[0, 1:1 + len(raw)] = np.frombuffer(raw, dtype=np.uint8).astype(np.int64) + 1
    return tokens


def _encode_words(text):
    width = HEAD_WORDS + TAIL_WORDS
    words_out = np.zeros((1, width), dtype=np.int64)
    words = text.lower().split()
    if len(words) > width:
        words = words[:HEAD_WORDS] + words[-TAIL_WORDS:]
    for slot, word in enumerate(words):
        digest = hashlib.blake2b(word.encode("utf-8", "surrogatepass"), digest_size=8).digest()
        words_out[0, slot] = int.from_bytes(digest, "little") % WORD_BUCKETS + 1
    return words_out


def state():
    global _STATE
    if _STATE is None:
        _STATE = {
            "meta": json.loads((BASE / "meta.json").read_text(encoding="utf-8")),
            "linear": _load_linear(),
            "cat": _load_cat(),
            "trans": _load_trans(),
        }
    return _STATE


def _linear_probability(text, state_):
    vocab, idf, coef, intercept = state_["linear"]
    indices, values = linear_features.vectorize(text, vocab, idf)
    logit = (float(np.dot(coef[indices], np.asarray(values))) + intercept) if indices else intercept
    return _sigmoid(logit)


def _cat_probability(text, state_):
    vocab, idf, model, meta = state_["cat"]
    indices, values = cat_features.vectorize(text, vocab, idf, int(meta["max_n"]))
    matrix = csr_matrix(
        (np.asarray(values, dtype=np.float32), np.asarray(indices, dtype=np.int32),
         np.asarray([0, len(indices)], dtype=np.int64)),
        shape=(1, int(meta["n_features"])),
    )
    return float(model.predict_proba(matrix, thread_count=1)[0, 1])


def _trans_probability(text, state_):
    scores, = state_["trans"].run(None, {"tokens": _encode_bytes(text), "words": _encode_words(text)})
    return _sigmoid(float(scores[0]))


def score(text):
    st = state()
    meta = st["meta"]
    p = (float(meta["w_linear"]) * _linear_probability(text, st)
         + float(meta["w_cat"]) * _cat_probability(text, st)
         + float(meta["w_trans"]) * _trans_probability(text, st))
    return p


def main():
    task = json.load(sys.stdin)
    probability = score(task.get("input", ""))
    threshold = float(state()["meta"]["threshold"])
    print(json.dumps({"answer": str(int(probability > threshold))}))


if __name__ == "__main__":
    main()
