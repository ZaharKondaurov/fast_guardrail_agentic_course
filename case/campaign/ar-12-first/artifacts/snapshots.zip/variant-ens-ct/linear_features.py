"""Deterministic text features shared by training and the frozen solver.

Feature space: lowercased word unigrams/bigrams and character 3-5 grams over
whitespace-collapsed NFKC text with boundary padding. Vocabulary is exact and
stored as one token per line; weights are TF-IDF with sublinear TF and L2 norm.
Only the standard library is needed for tokenization.
"""
import math
import re
import unicodedata
from collections import Counter

WORD = re.compile(r"[^\W_]+", re.UNICODE)
WS = re.compile(r"\s+")

CHAR_LO, CHAR_HI = 3, 5


def normalize(text: str) -> str:
    return WS.sub(" ", unicodedata.normalize("NFKC", text)).strip().lower()


def word_ngrams(text: str):
    words = WORD.findall(normalize(text))
    for i, word in enumerate(words):
        yield "w:" + word
        if i + 1 < len(words):
            yield "w:" + word + " " + words[i + 1]


def char_ngrams(text: str):
    padded = " " + normalize(text) + " "
    n = len(padded)
    for size in range(CHAR_LO, CHAR_HI + 1):
        for i in range(n - size + 1):
            yield "c:" + padded[i:i + size]


def all_ngrams(text: str):
    yield from word_ngrams(text)
    yield from char_ngrams(text)


def build_vocabulary(texts, min_df=2, max_features=500_000):
    counts = Counter()
    for text in texts:
        counts.update(set(all_ngrams(text)))
    items = [(token, df) for token, df in counts.items() if df >= min_df]
    items.sort(key=lambda item: (-item[1], item[0]))
    items = items[:max_features]
    items.sort(key=lambda item: item[0])
    return {token: index for index, (token, _) in enumerate(items)}


def document_frequencies(texts, vocab):
    df = [0] * len(vocab)
    for text in texts:
        for token in set(all_ngrams(text)):
            index = vocab.get(token)
            if index is not None:
                df[index] += 1
    return df


def idf_weights(df, n_documents):
    return [math.log((1.0 + n_documents) / (1.0 + value)) + 1.0 for value in df]


def vectorize(text: str, vocab, idf):
    """Return (indices, values) of the L2-normalised TF-IDF vector."""
    counts = Counter()
    for token in all_ngrams(text):
        index = vocab.get(token)
        if index is not None:
            counts[index] += 1
    if not counts:
        return [], []
    values = [(index, (1.0 + math.log(count)) * idf[index]) for index, count in counts.items()]
    norm = math.sqrt(sum(value * value for _, value in values))
    if norm == 0.0:
        return [], []
    values = [(index, value / norm) for index, value in values]
    values.sort()
    return [index for index, _ in values], [value for _, value in values]
