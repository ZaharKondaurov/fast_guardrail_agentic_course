"""Frozen solver: byte-level Transformer (seq 192), ONNX INT8, numpy+onnxruntime only."""
import json
import os
import sys
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import numpy as np
import onnxruntime as ort

BASE = Path(__file__).resolve().parent
SEQUENCE_LENGTH = 192
CLS_ID = 257


def encode(texts):
    """CLS token at slot 0, UTF-8 bytes + 1 afterwards, right padded with 0."""
    tokens = np.zeros((len(texts), SEQUENCE_LENGTH), dtype=np.int64)
    tokens[:, 0] = CLS_ID
    for index, text in enumerate(texts):
        raw = text.encode("utf-8", "surrogatepass")[: SEQUENCE_LENGTH - 1]
        if raw:
            tokens[index, 1:1 + len(raw)] = np.frombuffer(raw, dtype=np.uint8).astype(np.int64) + 1
    return tokens


def load():
    options = ort.SessionOptions()
    options.intra_op_num_threads = 1
    session = ort.InferenceSession(
        str(BASE / "model.onnx"), sess_options=options, providers=["CPUExecutionProvider"],
    )
    cutoff = float(json.loads((BASE / "model.json").read_text(encoding="utf-8"))["cutoff"])
    return session, cutoff


def classify(session, cutoff, text):
    scores, = session.run(None, {"tokens": encode([text])})
    return int(float(scores[0]) > cutoff)


if __name__ == "__main__":
    task = json.load(sys.stdin)
    session, cutoff = load()
    print(json.dumps({"answer": str(classify(session, cutoff, task["input"]))}))
