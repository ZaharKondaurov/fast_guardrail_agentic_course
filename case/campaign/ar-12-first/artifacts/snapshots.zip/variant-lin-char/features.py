"""Deterministic text features shared by training and the frozen solver.

One configurable feature space built from one or more deterministic text
"views".  Each view contributes word unigrams/bigrams and/or character
n-grams over whitespace-collapsed NFKC text; the character stream is padded
with one space so boundary n-grams exist.  Per-view TF-IDF vectors are
L2-normalised, concatenated, and the concatenation is divided by
sqrt(number of non-empty views) so that duplicated views (clean text under
two identical normalisations) keep the same geometry as a single view.

Only the Python standard library is needed at inference time.
"""
import math
import re
import unicodedata
from collections import Counter

# === CONFIG (generated) ===
CONFIG = {'views': [{'name': 'a', 'text': 'normal', 'word': None, 'char': [2, 6]}], 'min_df': 2, 'max_features': 1000000}
# === END CONFIG ===

WORD = re.compile(r"[^\W_]+", re.UNICODE)
WS = re.compile(r"\s+")
REPEAT = re.compile(r"(.)\1{2,}")
ESC_NONASCII = re.compile(r"\\(?=[^\x00-\x7f])")

# Greek / Cyrillic / misc characters that are routinely used as Latin
# homoglyphs in the encoding attacks present in this task.
HOMOGLYPHS = {
    # Cyrillic lower
    "\u0430": "a", "\u0432": "b", "\u0435": "e", "\u0451": "e",
    "\u043a": "k", "\u043c": "m", "\u043d": "h", "\u043e": "o",
    "\u0440": "p", "\u0441": "c", "\u0442": "t", "\u0443": "y",
    "\u0445": "x", "\u0456": "i", "\u0457": "i", "\u0458": "j",
    "\u0455": "s", "\u04bb": "h", "\u0501": "d", "\u051b": "q",
    "\u051d": "w", "\u04cf": "l", "\u0261": "g", "\u044c": "b",
    "\u0433": "r", "\u043f": "n",
    # Cyrillic upper
    "\u0410": "A", "\u0412": "B", "\u0415": "E", "\u0401": "E",
    "\u041a": "K", "\u041c": "M", "\u041d": "H", "\u041e": "O",
    "\u0420": "P", "\u0421": "C", "\u0422": "T", "\u0423": "Y",
    "\u0425": "X", "\u0406": "I", "\u0407": "I", "\u0408": "J",
    "\u0405": "S", "\u04ba": "H", "\u051a": "Q", "\u051c": "W",
    # Greek lower
    "\u03b1": "a", "\u03b2": "b", "\u03b3": "y", "\u03b5": "e",
    "\u03f5": "e", "\u03b9": "i", "\u03ba": "k", "\u03bd": "v",
    "\u03bf": "o", "\u03c1": "p", "\u03f1": "p", "\u03c4": "t",
    "\u03c5": "u", "\u03c7": "x", "\u03c9": "w", "\u03f2": "c",
    "\u03f3": "j",
    # Greek upper
    "\u0391": "A", "\u0392": "B", "\u0395": "E", "\u0396": "Z",
    "\u0397": "H", "\u0399": "I", "\u039a": "K", "\u039c": "M",
    "\u039d": "N", "\u039f": "O", "\u03a1": "P", "\u03a4": "T",
    "\u03a5": "Y", "\u03a7": "X", "\u03f9": "C",
}

LEET = {
    "0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "6": "g",
    "7": "t", "8": "b", "9": "g", "@": "a", "$": "s", "\u20ac": "e",
    "+": "t", "|": "l", "!": "i", "\u00a1": "i", "\u00a3": "e",
}

HOMOGLYPH_TABLE = str.maketrans(HOMOGLYPHS)
LEET_TABLE = str.maketrans(LEET)


def normalize(text: str) -> str:
    return WS.sub(" ", unicodedata.normalize("NFKC", text)).strip().lower()


def deobfuscate(text: str) -> str:
    """Deterministic deobfuscated copy used as an extra feature view."""
    value = unicodedata.normalize("NFKC", text)
    kept = []
    for ch in value:
        category = unicodedata.category(ch)
        if category in ("Cf", "Cc", "Cs", "Co", "Cn") and ch not in "\n\t":
            continue
        kept.append(ch)
    value = "".join(kept)
    value = ESC_NONASCII.sub("", value)
    value = value.translate(HOMOGLYPH_TABLE)
    value = value.translate(LEET_TABLE)
    value = REPEAT.sub(r"\1", value)
    return WS.sub(" ", value).strip().lower()


def make_view(kind: str):
    if kind == "normal":
        return normalize
    if kind == "deob":
        return deobfuscate
    raise ValueError(kind)


def view_texts(text: str):
    for view in CONFIG["views"]:
        yield view["name"], make_view(view["text"])(text)


def view_ngrams(view, text: str):
    word = view.get("word")
    char = view.get("char")
    if word:
        words = WORD.findall(text)
        for i, token in enumerate(words):
            yield "w:" + token
            for size in range(2, word[1] + 1):
                if i + size <= len(words):
                    yield "w:" + " ".join(words[i:i + size])
    if char:
        padded = " " + text + " "
        n = len(padded)
        for size in range(char[0], char[1] + 1):
            for i in range(n - size + 1):
                yield "c:" + padded[i:i + size]


def all_ngrams(text: str):
    for view in CONFIG["views"]:
        value = make_view(view["text"])(text)
        for token in view_ngrams(view, value):
            yield view["name"] + ":" + token


def build_vocabulary(texts, min_df=None, max_features=None):
    if min_df is None:
        min_df = CONFIG["min_df"]
    if max_features is None:
        max_features = CONFIG["max_features"]
    counts = Counter()
    for text in texts:
        counts.update(set(all_ngrams(text)))
    items = [(token, df) for token, df in counts.items() if df >= min_df]
    items.sort(key=lambda item: (-item[1], item[0]))
    items = items[:max_features]
    items.sort(key=lambda item: item[0])
    return {token: index for index, (token, _) in enumerate(items)}


def document_frequencies(texts, vocab):
    df = [0] * len(vocab)
    for text in texts:
        for token in set(all_ngrams(text)):
            index = vocab.get(token)
            if index is not None:
                df[index] += 1
    return df


def idf_weights(df, n_documents):
    return [math.log((1.0 + n_documents) / (1.0 + value)) + 1.0 for value in df]


def vectorize(text: str, vocab, idf):
    """Return (indices, values) of the frozen TF-IDF vector.

    Each view is L2-normalised on its own, then the concatenation is scaled
    by 1/sqrt(number of non-empty views)."""
    blocks = []
    for view in CONFIG["views"]:
        counts = Counter()
        value = make_view(view["text"])(text)
        for token in view_ngrams(view, value):
            index = vocab.get(view["name"] + ":" + token)
            if index is not None:
                counts[index] += 1
        if not counts:
            continue
        entries = [(index, (1.0 + math.log(count)) * idf[index]) for index, count in counts.items()]
        norm = math.sqrt(sum(value * value for _, value in entries))
        if norm == 0.0:
            continue
        blocks.append([(index, value / norm) for index, value in entries])
    if not blocks:
        return [], []
    scale = 1.0 / math.sqrt(len(blocks))
    merged = {}
    for block in blocks:
        for index, value in block:
            merged[index] = merged.get(index, 0.0) + value * scale
    values = sorted(merged.items())
    return [index for index, _ in values], [value for _, value in values]
