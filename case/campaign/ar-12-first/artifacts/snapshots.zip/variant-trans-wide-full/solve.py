"""Frozen solver: byte + hashed-word Transformer, ONNX INT8, numpy+onnxruntime only."""
import hashlib
import json
import os
import sys
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import numpy as np
import onnxruntime as ort

BASE = Path(__file__).resolve().parent
SEQUENCE_LENGTH = 192
CLS_ID = 257
WORD_BUCKETS = 4096
HEAD_WORDS = 40
TAIL_WORDS = 24


def encode_bytes(texts):
    """CLS token at slot 0, UTF-8 bytes + 1 afterwards, right padded with 0."""
    tokens = np.zeros((len(texts), SEQUENCE_LENGTH), dtype=np.int64)
    tokens[:, 0] = CLS_ID
    for index, text in enumerate(texts):
        raw = text.encode("utf-8", "surrogatepass")[: SEQUENCE_LENGTH - 1]
        if raw:
            tokens[index, 1:1 + len(raw)] = np.frombuffer(raw, dtype=np.uint8).astype(np.int64) + 1
    return tokens


def encode_words(texts):
    """First 40 + last 24 lower-cased words hashed into 4096 buckets with blake2b."""
    width = HEAD_WORDS + TAIL_WORDS
    words_out = np.zeros((len(texts), width), dtype=np.int64)
    for index, text in enumerate(texts):
        words = text.lower().split()
        if len(words) > width:
            words = words[:HEAD_WORDS] + words[-TAIL_WORDS:]
        for slot, word in enumerate(words):
            digest = hashlib.blake2b(word.encode("utf-8", "surrogatepass"), digest_size=8).digest()
            words_out[index, slot] = int.from_bytes(digest, "little") % WORD_BUCKETS + 1
    return words_out


def load():
    options = ort.SessionOptions()
    options.intra_op_num_threads = 1
    session = ort.InferenceSession(
        str(BASE / "model.onnx"), sess_options=options, providers=["CPUExecutionProvider"],
    )
    cutoff = float(json.loads((BASE / "model.json").read_text(encoding="utf-8"))["cutoff"])
    return session, cutoff


def classify(session, cutoff, text):
    scores, = session.run(None, {"tokens": encode_bytes([text]), "words": encode_words([text])})
    return int(float(scores[0]) > cutoff)


if __name__ == "__main__":
    task = json.load(sys.stdin)
    session, cutoff = load()
    print(json.dumps({"answer": str(classify(session, cutoff, task["input"]))}))
