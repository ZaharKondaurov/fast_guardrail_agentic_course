"""Frozen solver: TF-IDF linear model, standard library + NumPy only."""
import json
import math
import sys
from pathlib import Path

import numpy as np

from features import vectorize

BASE = Path(__file__).resolve().parent


def load():
    vocab = {}
    with (BASE / "vocab.txt").open(encoding="utf-8") as stream:
        for index, line in enumerate(stream):
            vocab[line.rstrip("\n")] = index
    data = np.load(BASE / "model.npz")
    meta = json.loads((BASE / "meta.json").read_text(encoding="utf-8"))
    return vocab, data["idf"].tolist(), data["coef"].astype(np.float64), float(data["intercept"]), float(meta["threshold"])


def main():
    vocab, idf, coef, intercept, threshold = load()
    task = json.load(sys.stdin)
    indices, values = vectorize(task["input"], vocab, idf)
    if indices:
        score = float(np.dot(coef[indices], np.asarray(values))) + intercept
    else:
        score = intercept
    probability = 1.0 / (1.0 + math.exp(-score)) if score > -700 else 0.0
    print(json.dumps({"answer": str(int(probability > threshold))}))


if __name__ == "__main__":
    main()
