"""Frozen solver: TF-IDF word/char features + CatBoost (NumPy/SciPy/CatBoost only)."""
import json
import sys
from pathlib import Path

import numpy as np
from catboost import CatBoostClassifier
from scipy.sparse import csr_matrix

from features_ext import load_vocab, vectorize

BASE = Path(__file__).resolve().parent
_STATE = None


def load():
    vocab = load_vocab(BASE / "vocab.txt")
    meta = json.loads((BASE / "meta.json").read_text(encoding="utf-8"))
    idf = np.load(BASE / "idf.npz")["idf"].astype(np.float64).tolist()
    model = CatBoostClassifier()
    model.load_model(str(BASE / "model.cbm"))
    return vocab, idf, model, meta


def state():
    global _STATE
    if _STATE is None:
        _STATE = load()
    return _STATE


def score(text):
    vocab, idf, model, meta = state()
    indices, values = vectorize(text, vocab, idf, int(meta["max_n"]))
    if meta.get("numeric"):
        import numeric_features
        feats = list(numeric_features.extract(text))
        base = len(vocab)
        indices = indices + [base + i for i in range(len(feats))]
        values = values + feats
    matrix = csr_matrix(
        (np.asarray(values, dtype=np.float32), np.asarray(indices, dtype=np.int32),
         np.asarray([0, len(indices)], dtype=np.int64)),
        shape=(1, int(meta["n_features"])),
    )
    return float(model.predict_proba(matrix, thread_count=1)[0, 1])


def main():
    task = json.load(sys.stdin)
    probability = score(task.get("input", ""))
    meta = state()[3]
    print(json.dumps({"answer": str(int(probability > float(meta["threshold"])))}))


if __name__ == "__main__":
    main()
