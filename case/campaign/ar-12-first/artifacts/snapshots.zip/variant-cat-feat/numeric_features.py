"""Explicit numeric features computed from raw text.

Shared verbatim by training and by the frozen solver; only the standard library
is used.  Every feature is a scalar computed from the single input string, so
the transformation is identical in both places.
"""
import math
import re
import unicodedata
from collections import Counter

WORD = re.compile(r"[^\W_]+", re.UNICODE)
WS = re.compile(r"\s+")
ALNUM = re.compile(r"[A-Za-z0-9+/=]{16,}")
ESC = re.compile(r"\\[xuU0-9nrt\\\"']")
LEET = re.compile(r"(?<=[A-Za-z])[0-9]+(?=[A-Za-z])")

# Generic instruction-control vocabulary (prompt-injection / jailbreak domain).
SUSPICIOUS = (
    "ignore", "disregard", "forget", "override", "bypass", "reveal", "repeat",
    "instructions", "instruction", "previous", "prior", "system", "prompt",
    "jailbreak", "dan", "developer", "assistant", "roleplay", "pretend",
    "hypothetical", "unrestricted", "unfiltered", "sudo", "admin", "password",
    "secret", "token", "rule", "rules", "policy", "safety", "guardrail",
    "base64", "hex", "rot13", "encode", "decode", "cipher", "decrypt",
    "ответ", "инструкц", "игнорир", "систем", "пароль", "правил",
)

FEATURE_NAMES = [
    "log_chars", "log_words", "log_lines", "mean_word_len", "max_word_len",
    "digit_ratio", "upper_ratio", "lower_ratio", "punct_ratio", "space_ratio",
    "nonascii_ratio", "control_ratio", "newline_ratio", "tab_ratio",
    "quote_ratio", "bracket_ratio", "unique_char_ratio", "char_entropy",
    "max_token_share", "distinct_token_ratio", "repeat_3gram_ratio",
    "suspicious_count_per100", "suspicious_share", "suspicious_distinct",
    "backslash_per100", "escape_seqs_per100", "long_alnum_runs",
    "max_alnum_run_len", "leet_token_ratio", "has_digit_word",
    "starts_upper_ratio", "exclaim_per100", "question_per100",
    "log_max_line_len", "digit_char_share_of_alnum", "nonletter_share",
]


def _safe_div(a, b):
    return a / b if b else 0.0


def extract(text: str):
    """Return the numeric feature vector (list of floats, fixed order)."""
    raw = text if isinstance(text, str) else ""
    n = len(raw)
    norm = WS.sub(" ", unicodedata.normalize("NFKC", raw)).strip().lower()
    words = WORD.findall(norm)
    n_words = len(words)
    lines = raw.split("\n")
    lower = raw.lower()

    digits = sum(1 for ch in raw if ch.isdigit())
    uppers = sum(1 for ch in raw if ch.isupper())
    lowers = sum(1 for ch in raw if ch.islower())
    spaces = sum(1 for ch in raw if ch.isspace())
    puncts = sum(1 for ch in raw if unicodedata.category(ch).startswith("P"))
    nonascii = sum(1 for ch in raw if ord(ch) > 127)
    controls = sum(1 for ch in raw if ord(ch) < 32 and ch not in "\n\t\r")
    newlines = raw.count("\n")
    tabs = raw.count("\t")
    quotes = raw.count('"') + raw.count("'") + raw.count("`")
    brackets = sum(raw.count(ch) for ch in "()[]{}<>")
    exclaims = raw.count("!")
    questions = raw.count("?")

    chars = Counter(raw.lower())
    total_chars = sum(chars.values())
    entropy = 0.0
    if total_chars:
        for count in chars.values():
            p = count / total_chars
            entropy -= p * math.log(p, 2)
        entropy /= 8.0

    token_counts = Counter(words)
    max_token_share = _safe_div(max(token_counts.values()) if token_counts else 0, n_words)
    distinct_token_ratio = _safe_div(len(token_counts), n_words)

    joined = " " + " ".join(words) + " "
    grams = Counter(joined[i:i + 3] for i in range(len(joined) - 2))
    repeat_3gram = 1.0 - _safe_div(len(grams), max(len(joined) - 2, 1))

    hits = [w for w in words if any(w.startswith(p) for p in SUSPICIOUS)]
    suspicious_share = _safe_div(len(hits), n_words)

    alnum_runs = ALNUM.findall(raw)
    leet = LEET.findall(raw)

    return [
        math.log1p(n),
        math.log1p(n_words),
        math.log1p(max(len(lines) - 1, 0)),
        _safe_div(n, n_words),
        float(max((len(w) for w in words), default=0)),
        _safe_div(digits, n),
        _safe_div(uppers, n),
        _safe_div(lowers, n),
        _safe_div(puncts, n),
        _safe_div(spaces, n),
        _safe_div(nonascii, n),
        _safe_div(controls, n),
        _safe_div(newlines, n),
        _safe_div(tabs, n),
        _safe_div(quotes, n),
        _safe_div(brackets, n),
        _safe_div(len(chars), n),
        entropy,
        max_token_share,
        distinct_token_ratio,
        repeat_3gram,
        _safe_div(100.0 * len(hits), n_words),
        suspicious_share,
        _safe_div(len(set(hits)), max(len(SUSPICIOUS), 1)),
        _safe_div(100.0 * raw.count("\\"), n),
        _safe_div(100.0 * len(ESC.findall(raw)), n),
        float(len(alnum_runs)),
        float(max((len(run) for run in alnum_runs), default=0)),
        _safe_div(len(leet), n_words),
        1.0 if any(any(ch.isdigit() for ch in w) for w in words) else 0.0,
        _safe_div(sum(1 for w in words if w[:1].isupper()), n_words),
        _safe_div(100.0 * exclaims, n),
        _safe_div(100.0 * questions, n),
        math.log1p(max((len(line) for line in lines), default=0)),
        _safe_div(digits, max(digits + uppers + lowers, 1)),
        _safe_div(n - uppers - lowers - digits - spaces, n),
    ]


def extract_matrix(texts):
    return [extract(text) for text in texts]
