"""Deterministic TF-IDF text features shared by training and the frozen solver.

Feature space: lowercased word n-grams (1..WORD_MAX_N) and character 3-5 grams
over whitespace-collapsed NFKC text with boundary padding.  Word and character
vocabularies are selected separately (own min_df and own cap), then concatenated
word-first so a single global index space is used by training and inference.

Vocabulary is exact and stored one token per line; weights are TF-IDF with
sublinear TF and L2 normalisation.  Only the standard library is needed for
tokenisation, so this module runs untouched inside the frozen candidate package.
"""
import math
import re
import unicodedata
from collections import Counter

WORD = re.compile(r"[^\W_]+", re.UNICODE)
WS = re.compile(r"\s+")

CHAR_LO, CHAR_HI = 3, 5
WORD_MAX_N = 3
WORD_PREFIX = "w:"
CHAR_PREFIX = "c:"


def normalize(text: str) -> str:
    return WS.sub(" ", unicodedata.normalize("NFKC", text)).strip().lower()


def word_ngrams(text: str, max_n: int = WORD_MAX_N):
    words = WORD.findall(normalize(text))
    n_words = len(words)
    for i, word in enumerate(words):
        yield WORD_PREFIX + word
        for size in range(2, max_n + 1):
            if i + size <= n_words:
                yield WORD_PREFIX + " ".join(words[i:i + size])


def char_ngrams(text: str):
    padded = " " + normalize(text) + " "
    n = len(padded)
    for size in range(CHAR_LO, CHAR_HI + 1):
        for i in range(n - size + 1):
            yield CHAR_PREFIX + padded[i:i + size]


def all_ngrams(text: str, max_n: int = WORD_MAX_N):
    yield from word_ngrams(text, max_n)
    yield from char_ngrams(text)


def count_documents(texts, max_n: int = WORD_MAX_N):
    """Document frequency of word and character n-grams, kept separate."""
    word_df = Counter()
    char_df = Counter()
    for text in texts:
        word_df.update(set(word_ngrams(text, max_n)))
        char_df.update(set(char_ngrams(text)))
    return word_df, char_df


def _select(counter, min_df, cap):
    items = [(token, df) for token, df in counter.items() if df >= min_df]
    items.sort(key=lambda item: (-item[1], item[0]))
    if cap is not None:
        items = items[:cap]
    items.sort(key=lambda item: item[0])
    return items


def build_parts(texts, min_df_word=2, min_df_char=2, max_word_features=None,
                max_char_features=None, max_n: int = WORD_MAX_N):
    """Return (vocab, df) with word features indexed before character features."""
    word_df, char_df = count_documents(texts, max_n)
    word_items = _select(word_df, min_df_word, max_word_features)
    char_items = _select(char_df, min_df_char, max_char_features)
    vocab = {}
    df = []
    for token, freq in word_items:
        vocab[token] = len(vocab)
        df.append(freq)
    for token, freq in char_items:
        vocab[token] = len(vocab)
        df.append(freq)
    return vocab, df


def idf_weights(df, n_documents):
    return [math.log((1.0 + n_documents) / (1.0 + value)) + 1.0 for value in df]


def vectorize(text: str, vocab, idf, max_n: int = WORD_MAX_N):
    """Return (indices, values) of the L2-normalised TF-IDF vector."""
    counts = Counter()
    get = vocab.get
    for token in all_ngrams(text, max_n):
        index = get(token)
        if index is not None:
            counts[index] += 1
    if not counts:
        return [], []
    values = [(index, (1.0 + math.log(count)) * idf[index]) for index, count in counts.items()]
    norm = math.sqrt(sum(value * value for _, value in values))
    if norm == 0.0:
        return [], []
    values = [(index, value / norm) for index, value in values]
    values.sort()
    return [index for index, _ in values], [value for _, value in values]


def save_vocab(path, vocab):
    with open(path, "w", encoding="utf-8") as stream:
        for token in vocab:
            stream.write(token + "\n")


def load_vocab(path):
    vocab = {}
    with open(path, encoding="utf-8") as stream:
        for index, line in enumerate(stream):
            vocab[line.rstrip("\n")] = index
    return vocab
