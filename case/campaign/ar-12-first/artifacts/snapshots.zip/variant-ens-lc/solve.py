"""Frozen ensemble solver: TF-IDF linear model + CatBoost model, probability blend.

Inference dependencies: Python stdlib, NumPy, SciPy and CatBoost only.
"""
import json
import math
import sys
from pathlib import Path

import numpy as np
from catboost import CatBoostClassifier
from scipy.sparse import csr_matrix

import cat_features
import linear_features

BASE = Path(__file__).resolve().parent
_STATE = None


def load_linear():
    vocab = {}
    with (BASE / "linear_vocab.txt").open(encoding="utf-8") as stream:
        for index, line in enumerate(stream):
            vocab[line.rstrip("\n")] = index
    data = np.load(BASE / "linear_model.npz")
    return (vocab, data["idf"].astype(np.float64).tolist(),
            data["coef"].astype(np.float64), float(data["intercept"]))


def load_cat():
    vocab = cat_features.load_vocab(BASE / "cat_vocab.txt")
    meta = json.loads((BASE / "cat_meta.json").read_text(encoding="utf-8"))
    idf = np.load(BASE / "cat_idf.npz")["idf"].astype(np.float64).tolist()
    model = CatBoostClassifier()
    model.load_model(str(BASE / "cat_model.cbm"))
    return vocab, idf, model, meta


def load():
    meta = json.loads((BASE / "meta.json").read_text(encoding="utf-8"))
    return {"meta": meta, "linear": load_linear(), "cat": load_cat()}


def state():
    global _STATE
    if _STATE is None:
        _STATE = load()
    return _STATE


def sigmoid(x):
    if x >= 0:
        return 1.0 / (1.0 + math.exp(-x))
    z = math.exp(x)
    return z / (1.0 + z)


def _logit(p):
    p = min(max(p, 1e-12), 1.0 - 1e-12)
    return math.log(p / (1.0 - p))


def linear_probability(text, state_):
    vocab, idf, coef, intercept = state_["linear"]
    indices, values = linear_features.vectorize(text, vocab, idf)
    if indices:
        logit = float(np.dot(coef[indices], np.asarray(values))) + intercept
    else:
        logit = intercept
    return sigmoid(logit)


def cat_probability(text, state_):
    vocab, idf, model, meta = state_["cat"]
    indices, values = cat_features.vectorize(text, vocab, idf, int(meta["max_n"]))
    if meta.get("numeric"):
        import cat_numeric
        feats = list(cat_numeric.extract(text))
        base = len(vocab)
        indices = indices + [base + i for i in range(len(feats))]
        values = values + feats
    matrix = csr_matrix(
        (np.asarray(values, dtype=np.float32), np.asarray(indices, dtype=np.int32),
         np.asarray([0, len(indices)], dtype=np.int64)),
        shape=(1, int(meta["n_features"])),
    )
    return float(model.predict_proba(matrix, thread_count=1)[0, 1])


def blend(p_lin, p_cat, meta):
    if meta["blend"] == "mean_logit":
        return sigmoid(0.5 * _logit(p_lin) + 0.5 * _logit(p_cat))
    weight = float(meta.get("weight_cat", 0.5))
    return (1.0 - weight) * p_lin + weight * p_cat


def score_both(text):
    state_ = state()
    return linear_probability(text, state_), cat_probability(text, state_)


def score(text):
    p_lin, p_cat = score_both(text)
    meta = state()["meta"]
    return blend(p_lin, p_cat, meta)


def main():
    task = json.load(sys.stdin)
    probability = score(task.get("input", ""))
    print(json.dumps({"answer": str(int(probability > float(state()["meta"]["threshold"])))}))


if __name__ == "__main__":
    main()
