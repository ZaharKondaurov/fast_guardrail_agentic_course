"""AR-12 solver: linear TF-IDF filter (variant-linear).

Reads one JSON object from stdin, e.g. {"input": "..."} and prints exactly one
JSON object: {"answer": "1"} for harmful/block, {"answer": "0"} for safe/pass.

Model: logistic regression over sublinear TF-IDF word 1-3 grams plus char_wb
2-5 grams, trained on the campaign's 80% train split with the campaign's fixed
split file; the decision threshold was frozen on the 20% calibration split.

The feature extraction below reproduces scikit-learn's `TfidfVectorizer`
(word 1-3, char_wb 2-5, sublinear tf, smooth idf, l2 norm) exactly; it is
verified score-identical to the sklearn pipeline that produced the model
(see reports/parity.json in the work directory). Keeping the runtime to the
standard library removes ~3.9 s of sklearn/scipy import per call and any
sklearn-version coupling in the runner.

No network access, no training data, no labels, no evaluation data in this
package.
"""

import array
import gzip
import json
import math
import pickle
import re
import sys
import unicodedata
from pathlib import Path

MODEL_PATH = Path(__file__).with_name("linear-tfidf.bin.gz")

_WORD_RE = re.compile(r"(?u)\b\w+\b")
_WHITE_SPACES = re.compile(r"\s\s+")
_COMBINING = unicodedata.combining
_state = {}


def _preprocess(text: str) -> str:
    """lowercase + strip_accents='unicode' exactly as sklearn does (word analyzer)."""
    text = text.lower()
    try:
        text.encode("ASCII", errors="strict")
        return text
    except UnicodeEncodeError:
        normalized = unicodedata.normalize("NFKD", text)
        return "".join(char for char in normalized if not _COMBINING(char))


def _word_ngrams(text: str, min_n: int = 1, max_n: int = 3) -> list:
    tokens = _WORD_RE.findall(text)
    ngrams = list(tokens)
    n_tokens = len(tokens)
    for n in range(max(min_n, 2), min(max_n, n_tokens) + 1):
        for index in range(n_tokens - n + 1):
            ngrams.append(" ".join(tokens[index : index + n]))
    return ngrams


def _char_wb_ngrams(text: str, min_n: int = 2, max_n: int = 5) -> list:
    text = _WHITE_SPACES.sub(" ", text)
    ngrams = []
    append = ngrams.append
    for word in text.split():
        word = " " + word + " "
        word_len = len(word)
        for n in range(min_n, max_n + 1):
            offset = 0
            append(word[0:n])
            while offset + n < word_len:
                offset += 1
                append(word[offset : offset + n])
            if offset == 0:  # short word (word_len < n): counted once
                break
    return ngrams


def _vectorize(ngrams, vocabulary: dict, idf: array.array) -> list:
    """Count -> sublinear tf -> idf -> l2 norm, as sklearn's TfidfTransformer."""
    counts: dict = {}
    for ngram in ngrams:
        index = vocabulary.get(ngram)
        if index is not None:
            counts[index] = counts.get(index, 0) + 1
    if not counts:
        return []
    weighted = [(index, (1.0 + math.log(count)) * idf[index]) for index, count in counts.items()]
    norm = math.sqrt(sum(value * value for _, value in weighted))
    if norm == 0.0:
        return []
    return [(index, value / norm) for index, value in weighted]


def load_state() -> dict:
    if not _state:
        with gzip.open(MODEL_PATH, "rb") as handle:
            artifact = pickle.load(handle)
        _state.update(artifact)
    return _state


def score(text: str) -> float:
    state = load_state()
    word_terms = _vectorize(_word_ngrams(_preprocess(text)), state["word_vocab"], state["word_idf"])
    # The char_wb vectorizer was fit without strip_accents: lowercase only.
    char_terms = _vectorize(_char_wb_ngrams(text.lower()), state["char_vocab"], state["char_idf"])
    coefficients = state["coef"]
    total = state["intercept"]
    for index, value in word_terms:
        total += coefficients[index] * value
    offset = state["word_offset"]
    for index, value in char_terms:
        total += coefficients[offset + index] * value
    return total


def classify(text: str) -> int:
    return int(score(text) >= load_state()["threshold"])


def main() -> None:
    try:
        task = json.load(sys.stdin)
    except Exception as exc:  # malformed stdin: never crash the runner
        print(f"solve: unreadable stdin ({exc}); defaulting to pass", file=sys.stderr)
        print(json.dumps({"answer": "0"}))
        return

    text = task.get("input") if isinstance(task, dict) else None
    if not isinstance(text, str):
        print("solve: missing or non-string 'input'; defaulting to pass", file=sys.stderr)
        print(json.dumps({"answer": "0"}))
        return

    if not text.strip():
        # No lexical evidence at all: the model would fall back to the training
        # prior (harmful is 64% of train) and block. An empty message cannot
        # carry an instruction, so pass it explicitly.
        print(json.dumps({"answer": "0"}))
        return

    try:
        answer = classify(text)
    except Exception as exc:
        print(f"solve: inference error ({exc}); defaulting to pass", file=sys.stderr)
        print(json.dumps({"answer": "0"}))
        return

    print(json.dumps({"answer": str(answer)}))


if __name__ == "__main__":
    main()
