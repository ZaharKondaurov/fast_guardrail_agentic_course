"""AR-12 message filter: TF-IDF (word + char) with CatBoost, calibrated threshold."""

import json
import sys
from pathlib import Path

import joblib
import numpy as np
from scipy.sparse import hstack

MODEL_PATH = Path(__file__).with_name("model.joblib")

SPECIALS = "{}[]<>|`\\\"'#"


def numeric_features(texts):
    rows = []
    for text in texts:
        n = max(len(text), 1)
        words = text.split()
        n_words = len(words)
        digits = sum(ch.isdigit() for ch in text)
        uppers = sum(ch.isupper() for ch in text)
        nonascii = sum(ord(ch) > 127 for ch in text)
        spaces = sum(ch.isspace() for ch in text)
        specials = sum(ch in SPECIALS for ch in text)
        newlines = text.count("\n")
        max_token = max((len(w) for w in words), default=0)
        unique_ratio = len(set(text)) / n
        rows.append([
            np.log1p(len(text)),
            np.log1p(n_words),
            np.log1p(len(text) / max(n_words, 1)),
            digits / n,
            uppers / n,
            nonascii / n,
            spaces / n,
            specials / n,
            np.log1p(newlines),
            np.log1p(max_token),
            unique_ratio,
        ])
    return np.asarray(rows, dtype=np.float32)


def features(texts, words, chars):
    return hstack(
        [words.transform(texts), chars.transform(texts), numeric_features(texts)],
        format="csr",
    )


def load_classifier():
    words, chars, model, probability_threshold = joblib.load(MODEL_PATH)

    def classify(text):
        inputs = features([text], words, chars)
        harmful_probability = model.predict_proba(inputs, thread_count=1)[0][1]
        return int(harmful_probability > probability_threshold)

    return classify


if __name__ == "__main__":
    task = json.load(sys.stdin)
    print(json.dumps({"answer": str(load_classifier()(task["input"]))}))
