"""AR-12 ensemble filter: TF-IDF CatBoost + byte transformer, calibrated on the 20% split.

Reads {"input": "..."} from stdin and prints {"answer": "0"|"1"}.
"""

import json
import sys
from pathlib import Path

import joblib
import numpy as np
import onnxruntime as ort
from scipy.sparse import hstack

HERE = Path(__file__).resolve().parent
CATBOOST_PATH = HERE / "catboost.onnx"
TRANSFORMER_PATH = HERE / "transformer.onnx"
VECTORIZER_PATH = HERE / "vectorizers.joblib"
CONFIG_PATH = HERE / "ensemble.json"
SEQUENCE_LENGTH = 128


def extra_features(texts):
    out = np.zeros((len(texts), 8), dtype=np.float32)
    for i, text in enumerate(texts):
        n = max(len(text), 1)
        words = text.split()
        out[i, 0] = np.log1p(len(text))
        out[i, 1] = np.log1p(len(words))
        out[i, 2] = np.mean([len(w) for w in words]) if words else 0.0
        out[i, 3] = sum(ch.isdigit() for ch in text) / n
        out[i, 4] = sum(ord(ch) > 127 for ch in text) / n
        out[i, 5] = sum(ch.isupper() for ch in text) / n
        out[i, 6] = sum(not ch.isalnum() and not ch.isspace() for ch in text) / n
        out[i, 7] = text.count("\n") / n * 10.0
    return out


def encode(texts):
    tokens = np.zeros((len(texts), SEQUENCE_LENGTH), dtype=np.int64)
    tokens[:, 0] = 257
    for index, text in enumerate(texts):
        prefix = text[: SEQUENCE_LENGTH - 1].encode("utf-8")[: SEQUENCE_LENGTH - 1]
        tokens[index, 1 : len(prefix) + 1] = np.frombuffer(prefix, dtype=np.uint8).astype(np.int64) + 1
    return tokens


def _session(path):
    options = ort.SessionOptions()
    options.intra_op_num_threads = 1
    return ort.InferenceSession(str(path), sess_options=options, providers=["CPUExecutionProvider"])


def load_classifier():
    vectorizers = joblib.load(VECTORIZER_PATH)
    words, chars = vectorizers["words"], vectorizers["chars"]
    config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    catboost = _session(CATBOOST_PATH)
    transformer = _session(TRANSFORMER_PATH)
    weights = config["weights"]
    w_cat = float(weights["catboost_logit"])
    w_tf = float(weights["transformer_score"])
    intercept = float(config["intercept"])
    threshold = float(config["threshold"])
    n_features = int(catboost.get_inputs()[0].shape[1])
    buffer = np.zeros((1, n_features), dtype=np.float32)
    catboost_input = catboost.get_inputs()[0].name
    transformer_input = transformer.get_inputs()[0].name

    def score(text):
        row = hstack([words.transform([text]), chars.transform([text]), extra_features([text])],
                     format="csr")
        buffer[:] = 0.0
        buffer[0, row.indices] = row.data
        probabilities = catboost.run(None, {catboost_input: buffer})[1]
        if isinstance(probabilities, list):
            harmful = float(probabilities[0][1])
        else:
            harmful = float(np.asarray(probabilities).reshape(-1, 2)[0, 1])
        harmful = min(max(harmful, 1e-7), 1 - 1e-7)
        logit = float(np.log(harmful / (1 - harmful)))
        tf_score = float(transformer.run(None, {transformer_input: encode([text])})[0][0])
        return w_cat * logit + w_tf * tf_score + intercept

    def classify(text):
        return int(score(text) > threshold)

    return classify


def main():
    task = json.load(sys.stdin)
    text = task.get("input", "")
    if not isinstance(text, str):
        text = "" if text is None else str(text)
    print(json.dumps({"answer": str(load_classifier()(text))}))


if __name__ == "__main__":
    main()
